#!/bin/bash
yum install -y tomcat8 java-1.8.0

