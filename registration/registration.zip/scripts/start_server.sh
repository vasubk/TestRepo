#!/bin/bash
service tomcat8 start
chkconfig tomcat8 on

